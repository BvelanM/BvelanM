def add(a,b):
 return a+b
def inp():
 a=12
 b=13
 #return add(a,b)
l=inp()
print(l)