import time
from twilio.rest import Client
from weatherc import weath

loc=[[11.0168,76.9558],]
for spec in loc:
    gflag=0
    dts=weath(spec[0],spec[1])#alert as dictionary from weatherc [calamityName:timeOfCalamity]
    print(dts)
    if dts!={}:    
      account_sid = 'AC56135befc249159d2ee1314cc63191cf'
      auth_token='738a7c49b9f8b3449e8e10e4af6c3295'
      client = Client(account_sid, auth_token)
      if 'L' in dts.keys():#if expected lightning  
        message = client.messages \
                        .create(
                            body="Calamity Alert! \n Thunderstrom expected on "+str(dts['L']) ,
                            from_='+17164520688',
                            to='+919489938682'
                        )
        print(message.sid)
      elif 'H' in dts.keys():#if expected heatwave
        message = client.messages \
                        .create(
                            body="Calamity Alert! \n Heatwaves expected on "+str(dts['H']) ,
                            from_='+17164520688',
                            to='+919489938682'
                        )
        print(message.sid)
      gflag=1
      timeflag=0#to denote if it is a first schedule message or a follow up
      while True:
            dts=weath(spec[0],spec[1],gflag)
            if timeflag==1:#non-first scheduled message
                if 'L' in dts.keys():
                    time.sleep(30)
                    message = client.messages \
                        .create(
                                body="The Thunderstrom may still continue ,\nPlease Stay Indoors",
                                from_='+17164520688',
                                to='+919489938682'
                                )
                    print(message.sid)
                elif 'H' in dts.keys():
                    time.sleep(30)
                    message = client.messages \
                            .create(
                                body="The Heatwaves may still continue ,\nPlease Stay Indoors",
                                from_='+17164520688',
                                to='+919489938682'
                                )
                    print(message.sid)
                elif 'safe' in dts.keys():
                    break
            elif timeflag==0:#first time shedule/currentcheck message
                timeflag=1
                if 'L' in dts.keys():
                    tempkey=dts['L']
                    message = client.messages \
                        .create(
                                body="The Thunderstrom may start around "+tempkey+" ,\nPlease Stay Indoors",
                                from_='+17164520688',
                                to='+919489938682'
                                )
                    print(message.sid)
                elif 'H' in dts.keys():
                    tempkey=dts['H']
                    message = client.messages \
                            .create(
                                body="The Heatwave may start around "+tempkey+" ,\nPlease Stay Indoors",
                                from_='+17164520688',
                                to='+919489938682'
                                )
                    print(message.sid)
                elif 'safe' in dts.keys():
                    break
    else:
        print("No msg sent")
        continue

