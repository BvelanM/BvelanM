from urllib import request
import requests
from tkinter import *
from datetime import datetime

api_key="bdfd28c561b64cc9ccca59cc715831ad"
dts={}
def gateway(time,wreport,ts):#function_that_defines_the_alert_(if any)
          global dts
          if time!='nei'and wreport=="no":
                  dts={'H':time,}
          elif wreport=='yes':
                  dts={'L':ts,}
def twodayc(response):#if no hourly calamity comes up this function is executed(is not executed during schedule checks)
        w_id=response['daily'][3]['weather'][0]['id'] #weatherid
        if w_id>200 and w_id<233:
          wreport="yes"
          timel=datetime.utcfromtimestamp(response['daily'][3]['dt']).strftime('%d-%m-%Y %H:%M:%S')#converts_unix_to_normall_time(string)
        else:
          wreport="no"
          timel=None
        temp=response['daily'][3]['temp']
        temp.pop('max')
        maxt = max(temp, key=temp.get) #maxtemp_of_the_day
        if temp[maxt]>=313.5:
            if maxt=='eve':
              time=datetime.utcfromtimestamp(response['daily'][3]['dt']).strftime('%d-%m-%Y') + ' Evening'
            elif maxt=='day':
              time=datetime.utcfromtimestamp(response['daily'][3]['dt']).strftime('%d-%m-%Y') + ' Afternoon'
            elif maxt=='night':
              time=datetime.utcfromtimestamp(response['daily'][3]['dt']).strftime('%d-%m-%Y') + ' Night'
        else:
          time='nei'
        gateway(time,wreport,timel)
def hourlyc(response,gflag=0):#the highest priority weather check which checks hourly
  flag=0
  if gflag==0:
    for i in range(0,len(response['hourly'])):
        w_id=response['hourly'][i]['weather'][0]['id'] #weatherid
        if w_id>200 and w_id<233:
          flag==1
          wreport="yes"
          ts=datetime.utcfromtimestamp(response['hourly'][i]['dt']).strftime('%H:%M')#converts_unix_to_normall_time(string)
        else:
          wreport="no"
          ts=None
        temp=response['hourly'][i]['temp']
        if temp>=313.5:
          flag=1
          ts=datetime.utcfromtimestamp(response['hourly'][i]['dt']).strftime('%H:%M')#converts_unix_to_normall_time(string)
        else:
          ts=='nei'
        if flag==1:#first time check
          gateway(ts,wreport,ts)
          break
    if flag==0:#first time check that calls 3rd day check if no hourly alert
      twodayc(response)
    else:
      return {'safe':'over'}
  elif gflag==1:
        w_id=response['hourly'][0]['weather'][0]['id'] #weatherid
        if w_id>200 and w_id<233:
          flag==1
          wreport="yes"
          ts=datetime.utcfromtimestamp(response['hourly'][0]['dt']).strftime('%H:%M')#converts_unix_to_normall_time(string)
        else:
          wreport="no"
          ts=None
        temp=response['hourly'][0]['temp']
        if temp>=313.5:
          flag=1
          ts=datetime.utcfromtimestamp(response['hourly'][0]['dt']).strftime('%H:%M')#converts_unix_to_normall_time(string)
        else:
          ts=='nei'
        if flag==1 and gflag==1:#schedule check
                gateway(ts,wreport,ts)
                return dts 
        elif gflag==1 and flag==0:
          return {'safe':'over'}
def weath(lat,lon,gflag=0):
    global api_key
    url=f"https://api.openweathermap.org/data/2.5/onecall?lat={lat}&lon={lon}&exclude={'current,minutely'}&appid={api_key}"#request to open weather database with customized lats and longs
    response = requests.get(url).json()
    if gflag==0:#flag that is used to identify whether this the first time check or a schedule check('0' if first time)
        hourlyc(response)
        return dts
    elif gflag==1:
        return hourlyc(response,gflag)