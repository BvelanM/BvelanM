from urllib import request
import requests
from tkinter import *
from datetime import datetime

api_key="bdfd28c561b64cc9ccca59cc715831ad"
dts={}
def gateway(time,wreport,ts):
          global dts
          if time!='nei' and wreport=="no":
                  dts={'H':time,}
          elif wreport=='yes':
                  dts={'L':ts,}
def twodayc(response):
        tempinp={0:234,1:234}
        w_id=tempinp[1] #weatherid
        if w_id>200 and w_id<233:
          wreport="yes"
          timel="now"
        else:
          wreport="no"
          timel=None
        maxt=315 #maxtemp_of_the_day
        if maxt>=313.5:
              time="now" + ' Night'
        else:
          time='nei'
        gateway(time,wreport,timel)
def hourlyc(response,gflag=0):
  flag=0
  if gflag==0:
    for i in range(0,2):
        tempinp={0:234,1:232}
        w_id=tempinp[i]#weatherid
        if w_id>200 and w_id<233:
          flag=1
          wreport="yes"
          ts='now'
        else:
          wreport="no"
          ts=None
        tempinph={0:300,1:300}
        temp=tempinph[i]
        if temp>=313.5:
          flag=1
          ts='now'
        else:
          ts=='nei'
        if flag==1 and gflag==0:
          gateway(ts,wreport,ts)
          break
        elif flag==1 and gflag==1:
          gateway(ts,wreport,ts)
          return dts
    if flag==0 and gflag==0:
      twodayc(response)
    else:
      return {'safe':'over'}
  elif gflag==1:
        w_id=response['hourly'][2]['weather'][0]['id'] #weatherid
        if w_id>200 and w_id<233:
          flag==1
          wreport="yes"
          ts=datetime.utcfromtimestamp(response['hourly'][2]['dt']).strftime('%H:%M')#converts_unix_to_normall_time(string)
        else:
          wreport="no"
          ts=None
        temp=response['hourly'][2]['temp']
        if temp>=313.5:
          flag=1
          ts=datetime.utcfromtimestamp(response['hourly'][2]['dt']).strftime('%H:%M')#converts_unix_to_normall_time(string)
        else:
          ts=='nei'
        if flag==1 and gflag==1:#schedule check
                gateway(ts,wreport,ts)
                return dts
        elif gflag==1 and flag==0:
          print('2')
          return {'safe':'over'}
def weath(lat,lon,gflag=0):
    global api_key
    url=f"https://api.openweathermap.org/data/2.5/onecall?lat={lat}&lon={lon}&exclude={'current,minutely'}&appid={api_key}"
    response = requests.get(url).json()
    if gflag==0:
        hourlyc(response)
        return dts
    elif gflag==1:
        return hourlyc(response,gflag)